class Order:
    def __init__(self):
        print("Order created")