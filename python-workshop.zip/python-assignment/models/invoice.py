class Invoice:
    def __init__(self):
        print("Invoice created")