from models.invoice import Invoice
from models.order import Order

p1 = Invoice()
p2 = Order()

